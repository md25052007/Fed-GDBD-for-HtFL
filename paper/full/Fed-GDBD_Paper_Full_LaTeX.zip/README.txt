LaTeX source of the paper (IEEEtran conference class).
Compile: pdflatex main.tex (run twice).
Overleaf: New Project > Upload Project > select this zip.
main.tex        paper text
generated.tex   result macros and tables, written by analysis/paper_figures.py from the logs
tables_repro.tex reproduction tables
refs_items.tex  references
figures/        plots, made by analysis/paper_figures.py from the logs
